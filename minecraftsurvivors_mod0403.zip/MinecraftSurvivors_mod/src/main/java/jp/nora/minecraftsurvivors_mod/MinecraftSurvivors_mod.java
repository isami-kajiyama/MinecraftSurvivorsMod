package jp.nora.minecraftsurvivors_mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import jp.nora.minecraftsurvivors_mod.custom_sounds.NetworkHandler;
import jp.nora.minecraftsurvivors_mod.custom_sounds.PlayBgmPacket;
import jp.nora.minecraftsurvivors_mod.custom_sounds.StopBgmPacket;
import jp.nora.minecraftsurvivors_mod.entity.render.RedZombieEntity;
import jp.nora.minecraftsurvivors_mod.ranking_board.NameInputScreen;
import jp.nora.minecraftsurvivors_mod.ranking_board.Networking;
import jp.nora.minecraftsurvivors_mod.ranking_board.OpenRankingScreenPacket;
import jp.nora.minecraftsurvivors_mod.regi.ClientEventBusSubscriber;
import jp.nora.minecraftsurvivors_mod.regi.CommonEventBusSubscriber;
import jp.nora.minecraftsurvivors_mod.regi.MobEntityTypes;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PressurePlateBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreCriteria;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.network.NetworkDirection;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.simple.SimpleChannel;
import net.minecraftforge.registries.IForgeRegistry;

import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

@Mod("minecraftsurvivors_mod")
public class MinecraftSurvivors_mod {
    // 以下の変数を追加
    private BlockPos originalPlayerPos;
    private ServerWorld originalPlayerWorld;
    private boolean gameActive = false;
    private long startTime = 0;
    private static int score = 0;
    private int numZombies = 2;
    private final int maxZombies = 50;
    private final int timeBetweenSpawns = 40; // 20 ticks = 1 second
    private int tickCounter = 0;
    private final int gameDuration = 80 * 20; // 20 ticks *
    private final Random random = new Random();
    private int countdown = 3;
    private boolean countdownInProgress = false;
    private long countdownStartTime;
    private boolean showMessage = false;
    private long showMessageStartTime;
    private int showMessageDuration = 2000; // 表示時間（ミリ秒）
    public static SoundEvent customBGM;
    public static final String MOD_ID = "minecraftsurvivors_mod";

    //ランキングボード
    private static int scoreboard;
    private static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder.named(new ResourceLocation("minecraftsurvivors", "open_name_input_screen"))
            .clientAcceptedVersions(a -> true)
            .serverAcceptedVersions(a -> true)
            .networkProtocolVersion(() -> "1.0")
            .simpleChannel();

    public static int getScore() {
        return score;
    }

//    @SubscribeEvent
//    public static void onSoundEventRegistry(final RegistryEvent.Register<SoundEvent> event) {
//        customBGM = new SoundEvent(new ResourceLocation("minecraftsurvivors_mod", "battle_bgm"));
//        customBGM.setRegistryName("minecraftsurvivors_mod", "battle_bgm");
//        event.getRegistry().register(customBGM);
//    }

    public MinecraftSurvivors_mod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Mod Event Busへの登録
        modEventBus.register(ModSounds.class);
        modEventBus.addListener(this::setup);
        MobEntityTypes.ENTITY_TYPES.register(modEventBus);
        modEventBus.addListener(this::onClientSetup);

        // Minecraft Forge Event Busへの登録
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ClientEventBusSubscriber());
        MinecraftForge.EVENT_BUS.register(new CommonEventBusSubscriber());

        // その他の設定
        registerMessages();
    }

    private void onClientSetup(final FMLClientSetupEvent event) {
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> ClientEventBusSubscriber::new); // renderRegister メソッドを実行するために、ClientEventBusSubscriber のインスタンスを作成します。
    }

    private void setup(final FMLCommonSetupEvent event) {
        NetworkHandler.init();
    }

    private void registerMessages() {
        CHANNEL.messageBuilder(OpenRankingScreenPacket.class, 0)
                .encoder((pkt, buf) -> {})
                .decoder(buf -> new OpenRankingScreenPacket())
                .consumer((BiConsumer<OpenRankingScreenPacket, Supplier<NetworkEvent.Context>>) (pkt, ctx) -> ctx.get().enqueueWork(() -> openNameInputScreen()))
                .add();
    }

//    public void displayRankingScreen() {
//        PlayerEntity player = Minecraft.getInstance().player;
//        if (player == null) {
//            return;
//        }
//
//        Scoreboard scoreboard = player.getEntityWorld().getScoreboard();
//        String scoreName = "Survivors Ranking";
//        ScoreObjective scoreObjective = scoreboard.getObjective(scoreName);
//
//        if (scoreObjective == null) {
//            scoreObjective = scoreboard.addObjective(scoreName, ScoreCriteria.DUMMY, new StringTextComponent(scoreName), ScoreCriteria.RenderType.INTEGER);
//        }
//
//        scoreboard.setObjectiveInDisplaySlot(0, scoreObjective);
//
//        // ランキングデータを取得して表示する処理
//        List<PlayerScore> rankingData = ScoreManager.loadScores();
//        int rank = 1;
//        for (PlayerScore entry : rankingData) {
//            String playerName = entry.getPlayerName();
//            int playerScore = entry.getScore();
//
//            // 既存のスコアボード機能を使用してスコアを設定し、サイドバーに表示
//            Score score = scoreboard.getOrCreateScore(playerName, scoreObjective);
//            score.setScorePoints(playerScore);
//
//            rank++;
//        }
//    }

    @SubscribeEvent
    public static void onSoundEventRegistry(final RegistryEvent.Register<SoundEvent> event) {
        IForgeRegistry<SoundEvent> registry = event.getRegistry();

        customBGM = new SoundEvent(new ResourceLocation("minecraftsurvivors_mod","battle_bgm"));
        //pathはsoundsフォルダより後の部分を指定.ogg拡張子は不要
        registry.register(customBGM);
    }


    //値をリセットするメソッド
    public void reset(){
        gameActive = false;
        startTime = 0;
        score = 0;
        numZombies = 2;
        tickCounter = 0;
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        PlayerEntity player = event.player;
        World world = player.getEntityWorld();

        if (!world.isRemote) {
            BlockPos platePos = new BlockPos(player.getPosX(), player.getPosY() - 1, player.getPosZ());
            BlockState plateState = world.getBlockState(platePos);

            // プレートが押されたかどうか確認
            if (plateState.getBlock() == Blocks.STONE_PRESSURE_PLATE && plateState.get(PressurePlateBlock.POWERED)) {
                if (!gameActive && !countdownInProgress) {
                    originalPlayerPos = player.getPosition();
                    originalPlayerWorld = ((ServerPlayerEntity) player).getServerWorld();

                    // ゲームフィールドの生成
                    BlockPos gameFieldCenter = new BlockPos(5000, 100, 0);
                    createGameField(world, gameFieldCenter);

                    countdownInProgress = true;
                    countdownStartTime = System.currentTimeMillis();
                    player.sendStatusMessage(new StringTextComponent(TextFormatting.YELLOW + "Countdown started..."), false);

                }
            }

            if (countdownInProgress) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - countdownStartTime >= 1000) {
                    countdownStartTime = currentTime;
                    countdown--;

                    if (countdown == 0) {
                        startGame(player);
                        countdownInProgress = false;
                        countdown = 4;
                    } else {
                        player.sendStatusMessage(new StringTextComponent(TextFormatting.YELLOW + "Game starts in: " + countdown), false);
                    }
                }
            }

            if (gameActive) {
                tickCounter++;

                // ゲーム時間が経過したらゲーム終了
                if (tickCounter >= gameDuration) {
                    endGame(player);
                }

                // 時間経過でゾンビをスポーンさせる
                if (tickCounter % timeBetweenSpawns == 0 && numZombies < maxZombies) {
                    // 経過時間に応じて、一定間隔でゾンビの数を増やす
                    int additionalZombies = tickCounter / (20 * 10); // 30秒ごとにゾンビを1ずつ増やす
                    spawnZombies(world, player, 1 + additionalZombies, 5, 10);
                    numZombies++;
                }
            }
        }
    }

    @SubscribeEvent
    public void onEntityDeath(LivingDeathEvent event) throws InterruptedException {
        // ゾンビを倒したらスコアを加算
        if (gameActive && event.getEntity() instanceof ZombieEntity && event.getSource().getTrueSource() instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) event.getSource().getTrueSource();
            MinecraftSurvivors_mod.score+=100;

            // スコアボードを取得し、スコアを更新
            Scoreboard scoreboard = player.getEntityWorld().getScoreboard();
            String scoreName = "Survivors";
            ScoreObjective scoreObjective = scoreboard.getObjective(scoreName);

            if (scoreObjective != null) {
                Score score = scoreboard.getOrCreateScore(player.getDisplayName().getString(), scoreObjective);
                score.setScorePoints(MinecraftSurvivors_mod.score);
            }

        }

        // プレイヤーが死亡した場合、ゲームを終了
        if (gameActive && event.getEntity() instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) event.getEntity();
            endGame(player);
        }
    }

//    @SubscribeEvent
//    public void onMobSpawn(LivingSpawnEvent.CheckSpawn event) {
//        // ゾンビ以外のモブのスポーン禁止
//        if (gameActive && !(event.getEntityLiving() instanceof ZombieEntity)) {
//            event.setResult(Event.Result.DENY);
//        }
//    }

    //画面中央の文字表示
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event) {
        // イベントタイプがTEXTであることを確認
        if (event.getType() != RenderGameOverlayEvent.ElementType.TEXT) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }

        // 1秒間だけメッセージを表示する
        long currentTime = System.currentTimeMillis();
        if (showMessage && currentTime - showMessageStartTime < 1000) {
            String text = "GameStart!";
            FontRenderer fontRenderer = minecraft.fontRenderer;
            MatrixStack matrixStack = new MatrixStack();
            int scale = 4;
            float alpha = 1.0f - (float)(currentTime - showMessageStartTime) / 1000.0f;
            int color = (int)(alpha * 255.0f) << 24 | 0xFFFFFF;
            int x = (minecraft.getMainWindow().getScaledWidth() - fontRenderer.getStringWidth(text) * scale) / 2;
            int y = (int)(minecraft.getMainWindow().getScaledHeight() * 0.3);
            matrixStack.push();
            matrixStack.translate(x, y, 0);
            matrixStack.scale(scale, scale, 1);
            fontRenderer.drawStringWithShadow(matrixStack, text, 0, 0, color);
            matrixStack.pop();
        }

        // ゲーム時間の表示
        if (gameActive) {
            int remainingTime = gameDuration - tickCounter;
            int remainingSeconds = remainingTime / 20;

            String text = remainingSeconds + "s";
            FontRenderer fontRenderer = minecraft.fontRenderer;

            // 画面の幅と高さを取得
            int screenWidth = minecraft.getMainWindow().getScaledWidth();
            int screenHeight = minecraft.getMainWindow().getScaledHeight();

            // 文字列の幅を取得
            int stringWidth = fontRenderer.getStringWidth(text);

            // 座標を画面中央の最上部に変更
            int x = (screenWidth - stringWidth) / 2;
            int y = 2;

            // MatrixStack オブジェクトを取得
            MatrixStack matrixStack = event.getMatrixStack();

            // MatrixStack オブジェクトを引数に追加
            fontRenderer.drawStringWithShadow(matrixStack, text, x, y, 0xFFFFFF);
        }

    }

    private void startGame(PlayerEntity player) {

        score = 0;
        gameActive = true;
        startTime = System.currentTimeMillis();
        player.sendStatusMessage(new StringTextComponent("MINECRAFT SURVIVORS START"), false);

        // スコアボードを作成
        Scoreboard scoreboard = player.getEntityWorld().getScoreboard();
        String scoreName = "Survivors";
        ScoreObjective scoreObjective = scoreboard.getObjective(scoreName);
        scoreboard.setObjectiveInDisplaySlot(1, scoreObjective); // 1はサイドバーに表示することを意味します

        // スコアボードが存在しない場合、新たに作成
        if (scoreObjective == null) {
            scoreObjective = scoreboard.addObjective(scoreName, ScoreCriteria.DUMMY, new StringTextComponent("Score"), ScoreCriteria.RenderType.INTEGER);
        }

        // スコアボードを表示
        scoreboard.setObjectiveInDisplaySlot(1, scoreObjective); // 1はサイドバーに表示することを意味します

        // ゲームフィールドに移動
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
            ServerWorld serverWorld = serverPlayer.getServerWorld();
            BlockPos gameFieldPos = new BlockPos(5000, 100, 0); // ゲームフィールドの中心座標を指定
            serverPlayer.teleport(serverWorld, gameFieldPos.getX(), gameFieldPos.getY(), gameFieldPos.getZ(), player.rotationYaw, player.rotationPitch);

            // ゲームスタート時に強制的に夜時間に変更
            serverWorld.setDayTime(13000);
        }

        // ゲーム開始時にカスタムBGMを再生
        //player.world.playSound(null, player.getPosition(), new SoundEvent(new ResourceLocation("minecraftsurvivors_mod","battle_bgm")), SoundCategory.MUSIC, 0.5F, 1.0F);

        // BGMの再生を開始
        ResourceLocation bgmLocation = new ResourceLocation("minecraftsurvivors_mod", "battle_bgm");
        NetworkHandler.INSTANCE.send(PacketDistributor.ALL.noArg(), new PlayBgmPacket(bgmLocation, true));

        showMessage = true;
        showMessageStartTime = System.currentTimeMillis();

    }


    // ゲームフィールドの生成メソッドを追加
    private void createGameField(World world, BlockPos center) {
        int fieldSize = 50;
        int lavaBorderWidth = 10; // 溶岩の幅を1ブロックに設定
        for (int x = -fieldSize / 2 - lavaBorderWidth; x <= fieldSize / 2 + lavaBorderWidth; x++) {
            for (int z = -fieldSize / 2 - lavaBorderWidth; z <= fieldSize / 2 + lavaBorderWidth; z++) {
                BlockPos blockPos = center.add(x, -1, z);

                // ゲームフィールドの内側にあるブロックをグロウストーンに設定
                if (x > -fieldSize / 2 && x < fieldSize / 2 && z > -fieldSize / 2 && z < fieldSize / 2) {
                    world.setBlockState(blockPos, Blocks.GLOWSTONE.getDefaultState());
                } else {
                    // ゲームフィールドの周りにあるブロックを溶岩に設定
                    world.setBlockState(blockPos, Blocks.LAVA.getDefaultState());
                }
            }
        }
    }

    private void endGame(PlayerEntity player) {

        gameActive = false;
        tickCounter = 0;

        // プレイヤーの状態をリセット
        player.setHealth(player.getMaxHealth());
        player.getFoodStats().setFoodLevel(20);

        player.sendStatusMessage(new StringTextComponent("Game Over! Score: " + score), false);

        // 元の場所に戻る
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
            serverPlayer.teleport(originalPlayerWorld, originalPlayerPos.getX(), originalPlayerPos.getY(), originalPlayerPos.getZ(), player.rotationYaw, player.rotationPitch);
        }

        ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
        ServerWorld serverWorld = serverPlayer.getServerWorld();
        serverWorld.setDayTime(0);

        //BGMの再生を停止
        ResourceLocation bgmLocation = new ResourceLocation("minecraftsurvivors_mod", "battle_bgm");
        NetworkHandler.INSTANCE.send(PacketDistributor.ALL.noArg(), new StopBgmPacket(bgmLocation));

        // ゲーム終了後にMOBをすべてキルする
//        List<Entity> entities = serverWorld.getEntities().collect(Collectors.toList());
//        for (Entity entity : entities) {
//            if (entity instanceof MobEntity) {
//                entity.remove();
//            }
//        }

        // ゲーム終了後にランキング画面を表示する
        //sendDisplayRankingScreenPacket(player);

        Minecraft.getInstance().displayGuiScreen(new NameInputScreen());

        // スコアボードを非表示にする
        Scoreboard scoreboard = player.getEntityWorld().getScoreboard();
        String scoreName = "Survivors";
        ScoreObjective scoreObjective = scoreboard.getObjective(scoreName);

        // 1 はサイドバーに表示することを意味します
        scoreboard.setObjectiveInDisplaySlot(1, null); // スロットを null に設定することで、サイドバーから削除されます

        // スコアをリセット
        Score score = scoreboard.getOrCreateScore(player.getScoreboardName(), scoreObjective);
        score.setScorePoints(0);

    }

    public void sendDisplayRankingScreenPacket(PlayerEntity player) {
        if (player instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
            OpenRankingScreenPacket packet = new OpenRankingScreenPacket();
            Networking.INSTANCE.sendTo(packet, serverPlayer.connection.netManager, NetworkDirection.PLAY_TO_CLIENT);
        }
    }


    private void openNameInputScreen() {
        Minecraft.getInstance().enqueue(() -> {
            Minecraft.getInstance().displayGuiScreen(new NameInputScreen());
        });
    }

    private void spawnZombies(World world, PlayerEntity player, int numZombies, double minRadius, double maxRadius) {
        Random random = new Random();
        for (int i = 0; i < numZombies; i++) {
            double angle = random.nextDouble() * 2 * Math.PI;
            double radius = minRadius + (maxRadius - minRadius) * random.nextDouble();
            double spawnX = player.getPosX() + radius * Math.cos(angle);
            double spawnZ = player.getPosZ() + radius * Math.sin(angle);
            BlockPos spawnPos = new BlockPos(spawnX, player.getPosY(), spawnZ);

            // 鶏が出現する確率を10%に設定
            float chickenChance = 0.1f;

            if (random.nextFloat() < chickenChance) {
                ChickenEntity chicken = new ChickenEntity(EntityType.CHICKEN, world);
                chicken.setPosition(spawnX, player.getPosY(), spawnZ);
                world.addEntity(chicken);
            } else {
                // RedZombieが出現する確率を10%に設定
                float redZombieChance = 0.1f;

                if (random.nextFloat() < redZombieChance) {
                    RedZombieEntity redZombie = new RedZombieEntity(MobEntityTypes.RED_ZOMBIE.get(), world);
                    redZombie.setPosition(spawnX, player.getPosY(), spawnZ);
                    world.addEntity(redZombie);
                } else {
                    ZombieEntity zombie = new ZombieEntity(EntityType.ZOMBIE, world);
                    zombie.setPosition(spawnX, player.getPosY(), spawnZ);

                    // ゾンビの体力を1に設定
                    zombie.setHealth(0.5F);

                    // ゾンビの攻撃力を変更
                    zombie.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2.0D);

                    // 子ゾンビの確率を設定
                    float childZombieChance = 0.3f;

                    // 子ゾンビを生成
                    if (random.nextFloat() < childZombieChance) {
                        ZombieEntity childZombie = new ZombieEntity(EntityType.ZOMBIE, world);
                        childZombie.setChild(true);
                        childZombie.setPosition(spawnX, player.getPosY(), spawnZ);

                        // 子ゾンビの体力を3に設定
                        childZombie.setHealth(0.5F);

                        // 子ゾンビの攻撃力を変更
                        childZombie.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1.0D);

                        world.addEntity(childZombie);
                    } else {
                        world.addEntity(zombie);
                    }
                }
            }
        }
    }
}

