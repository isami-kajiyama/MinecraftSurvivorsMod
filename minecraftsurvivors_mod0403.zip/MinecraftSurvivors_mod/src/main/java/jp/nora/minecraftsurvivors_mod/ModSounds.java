package jp.nora.minecraftsurvivors_mod;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.ObjectHolder;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModSounds {
    public static SoundEvent customBGM;

    @SubscribeEvent
    public static void onSoundEventRegistry(final RegistryEvent.Register<SoundEvent> event) {
        IForgeRegistry<SoundEvent> registry = event.getRegistry();

        customBGM = new SoundEvent(new ResourceLocation("minecraftsurvivors_mod", "battle_bgm"));
        //pathはsoundsフォルダより後の部分を指定.ogg拡張子は不要
        registry.register(customBGM.setRegistryName("minecraftsurvivors_mod", "battle_bgm"));
        event.getRegistry().register(customBGM);
    }


}
