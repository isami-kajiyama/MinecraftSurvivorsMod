package jp.nora.minecraftsurvivors_mod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

import java.util.List;

public class GoldChickenEntity extends ChickenEntity {

    public GoldChickenEntity(EntityType<? extends ChickenEntity> type, World world) {
        super(type, world);

        // 体力を1に設定
        this.setHealth(0.5F);
    }

    @Override
    public void onDeath(DamageSource cause) {
        super.onDeath(cause);

        // プレイヤーが近くにいるかどうかをチェックするための範囲
        double range = 8.0;

        // 鶏の周りのプレイヤーをリストアップ
        List<PlayerEntity> players = this.world.getEntitiesWithinAABB(PlayerEntity.class, this.getBoundingBox().grow(range));

        // 近くのプレイヤーの体力を半分回復
        for (PlayerEntity player : players) {
            float halfHealth = player.getMaxHealth() / 2.0F;
            player.setHealth(Math.min(player.getHealth() + halfHealth, player.getMaxHealth()));
        }
    }
}

